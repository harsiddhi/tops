<?php
define("CONNECTION1",dirname(dirname(__FILE__)));
include CONNECTION1 .'/connection.php' ;
include CONNECTION1 . '../doa/doa.php';

class model
{
	public function insertData($tbl,$data)
	{
		$doaObj = new Doa();
		$connection = new connection();
		$conn = $connection->connect();
		$columnData = $doaObj->doaData($tbl,$conn);
		$data['education'] = implode(" ", $data['education']) ;
		$strcolumn = implode(",",$columnData);
		array_pop($data);

	$sql = "INSERT INTO $tbl (" . implode(', ', $columnData) . ") "
         . "VALUES ('" . implode("', '", $data) . "')";

         //print_r($sql);

         $sqlquery = mysqli_query($conn,$sql);
         return $sqlquery;
         //print_r($sqlquery);
		
	}
	public function deleteData($tbl,$id)
	{
			echo $tbl ;
			$connection = new connection();
		$conn = $connection->connect();
			$query = "delete FROM $tbl where id = '$id'";
			$sqlquery = mysqli_query($conn,$query);
         return $sqlquery;

	}
	public function updateData()
	{

	}
	public function listData($tbl)
	{

		$sql = "select * from $tbl";
		$connection = new connection();
		$conn = $connection->connect();
		$result = mysqli_query($conn,$sql);
		while($resulObj = mysqli_fetch_object($result))
		{
					$allresult[]= $resulObj;


		}
		
		return $allresult;




	}
}
?>