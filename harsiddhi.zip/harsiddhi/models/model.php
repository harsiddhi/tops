<?php
//include '../connection.php';


function insertstd($name,$email,$password)
{
	
	$sql = "INSERT INTO std (name,email,password)
VALUES ('$name','email','$password')";
return ($sql);





	

} 
?>