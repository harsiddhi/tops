
<?php
define("CONNECTION",dirname(dirname(__FILE__)));
include CONNECTION .'/connection.php' ;
class LoginModel
{
	public function Logindata($email,$pass)
	{
			$connection = new connection();
			$conn = $connection->connect();
			$sql = "SELECT ID FROM STD where email='$email' and pass='$pass'";
			$result = mysqli_query($conn,$sql);
			$row = mysqli_fetch_row($result);
			$count = mysqli_num_rows($result);
			return $count;



	}

}
?>