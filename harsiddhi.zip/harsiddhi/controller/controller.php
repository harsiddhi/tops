<?php
include '../connection.php';
include '../models/studentmodel.php';

$action = $_POST['reg'];
//echo $action;
if($action == 'reg')
{
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$password = $_REQUEST['password'];
$password = md5($password);
$result = insertstd($name,$email,$password);
//print_r($result);
///$resultOfQuery = mysqli_query($result,$conn);
$boolresult = mysqli_query($result,$conn);
print_r($boolresult);



}

?>