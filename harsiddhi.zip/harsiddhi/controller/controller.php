<?php
define("MODELPATHM",dirname(dirname(__FILE__)));
include MODELPATHM .'/models/model.php';
class controller
{

	public function checkAction()
	{
		
		$action = $_REQUEST['action'];
		$tbl = 'std';
		if(strtolower($action))
		{
			switch ($action) {
				case 'registration':
					$data = $_POST;
					$result= $this->actioninsert($tbl,$data);
					if($result)
					{
						header('Location:../index.php');
						exit();
;
					}
					else
					{
						header('Location:../view/insert.php');
						exit();

					}



					# code...
					break;
				
				default:
					# code...
					break;
			}
		}

	}

	public function actioninsert($tbl,$data)
	{
			$modelObj = new model();
			$result = $modelObj->insertData($tbl,$data);
			return $result;

	}
	
} 
$controllerObj = new controller();
$controllerObj->checkAction();
?>