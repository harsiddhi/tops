<?php
class Doa
{
	public function doaData($tbl,$conn)
	{
		$sql1 = "SHOW COLUMNS FROM $tbl";
		
		$sql2= "SHOW KEYS FROM $tbl WHERE Key_name = 'PRIMARY'";
		$result1 =  mysqli_query($conn,$sql1);

		$result2 = mysqli_query($conn,$sql2);

		while($row = mysqli_fetch_array($result1))
		{
			$output1[] = $row[0];
		}

		$output2=  mysqli_fetch_array($result2);

		$array2[] = $output2['Column_name'];


		//print_r($output1);

		$resultColumn=array_diff($output1,$array2);
		//print_r($resultColumn);
		return $resultColumn;



	}
}
?>