<!DOCTYPE html>

<html>
<head>
	<title></title>
</head>
<body>
<center>
	<form method="POST" name="registration" action="../controller/studentcontroller.php">
		<table border="1">
		TOPS-Technology 
			
			<tr>
				<td>Name</td>
				<td><input type="text" name="name"></td>
			</tr>
			
			<tr>
				<td>Email</td>
				<td><input type="email" name="email"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<!--<td>gender</td>
				<!--<td>
				<input type="radio" name="gender" value="0">male
				<input type="radio" name="gender" value="1">female</td> -->
			</tr>
							
							<input type="hidden" name="reg" value="reg">

			
			<tr> 
				<td><input type="submit"></td>
			</tr>
			</table>
			</form>
			
			
			</center>


			
</body>
</html>