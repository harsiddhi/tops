<!DOCTYPE html>
<?php define("MODELDATA1",dirname(dirname(__FILE__)));

include MODELDATA1 .'/models/model.php' ;
?>
<html>
<head>
	<title></title>
</head>
<body>
<center>
<?php
$id = $_REQUEST['id'];
$modelobj  = new model();
$tbl = "std";
$result = $modelobj->updateIDDetail($tbl,$id);
print_r($result);
// $result['education'] = explode(" ",$result['education']) ;
echo $id; 
?>
	<form method="POST" name="registration" action="../controller/controller.php?id=<?php echo $id?>" enctype="multipart/form-data">
		<table border="1">
		<h2>TOPS-Technology</h2> 
			
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $result->name?>" required></td>
			</tr>
			
			<tr>
				<td>Email</td>
				<td><input type="email" name="email"  value="echo $result->email"required></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="pass" required></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender" value="0"  <?php echo ($result->gender=='0')?'checked':'' ?>>Male
				<input type="radio" name="gender" value="1"  <?php echo ($result->gender=='1')?'checked':'' ?>>Female</td>
			</tr>

			<tr>
				<td>Education</td>
				<td><input type="checkbox" name="education[]" value="MCA" checked>MCA
				<input type="checkbox" name="education[]" value="BCA">BCA</td>

			</tr>

			<tr>
				<td>City</td>
							<td>

				<select name="city" required value="">
				<option name="Ahmedabd">Ahmedabd
				</option>
				<option name="Surat">Surat
				</option>
				</select>
							</td>

			</tr>


			<tr>
				<td>Image</td>
				<td><input type="text" name="images" required ></td>
			</tr>
			<tr>
				<!--<td>gender</td>
				<!--<td>
				<input type="radio" name="gender" value="0">male
				<input type="radio" name="gender" value="1">female</td> -->
			</tr>
							
							<input type="hidden" name="action" value="update">

			
			<tr> 
				<td><input type="submit"></td>
			</tr>
			</table>
			</form>
			
			
			</center>


			
</body>
</html>