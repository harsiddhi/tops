<?php
$action = 'delete'; 
$id= $_REQUEST['id'];
echo $id ;
die();
?>