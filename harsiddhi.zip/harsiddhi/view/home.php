<?php
session_start();
define("MODELDATA",dirname(dirname(__FILE__)));

include MODELDATA .'/models/model.php' ;
//include MODELDATA .'/doa/doa.php';
//include MODELDATA .'/connection.php';
 $_SESSION['tbl'] = 'std';
 $tbl = $_SESSION['tbl'];
$modelobj  = new model();
$result = $modelobj->listData($tbl);
//print_r($result);

if(isset($_SESSION['name']))
{ ?><p style="color:red"><?php 
	echo "hello" . " " .$_SESSION['name'];
	?>
	</p>
	<center>
		<table border="1">
		<tr>
				<?php

					$doaObj = new Doa();
					$connection = new connection();
					$conn = $connection->connect();
					$columnData= $doaObj->doaData($tbl,$conn);
					$values = array_values($columnData);
					$count = count($values);

					//print_r($count);
					foreach ($values as $v) {
						?><TH><?php 
						echo $v; ?>
						</TH>
						<?php

						# code...
					}
						?>

						<?php
						foreach ($result as $k) {
							?><tr>

							<td>
									<?php echo $k->name; ?>
							</td>
							<td>
									<?php echo $k->email; ?>
							</td>
							<td>
									<?php echo $k->pass; ?>
							</td>
							<td>
									<?php  $k->gender;
									if($k->gender ==0)
									{
											echo "male";
									}
									else
									{
										echo "Female";

									}

									 ?>
							</td>
							<td>
									<?php echo $k->education; ?>
							</td>
							<td>
									<?php echo $k->city; ?>
							</td>
							<td>
									<?php echo $k->images; ?>
							</td>

							<td>
									<a href="delete.php" value="<?php echo $k->id?>">DELETE</a>
									<a href="update.php" value="<?php echo $k->id?>">UPDATE</a>
							</td>
							<?php
							//die();
						 	# code...
						 } 
						?>

					</table>
	</center>
	<p>
	<a href="logout.php">LOGOUT</a>
	</p>
<?php
}

?>