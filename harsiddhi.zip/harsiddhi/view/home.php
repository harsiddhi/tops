<?php
session_start();
//$name = $_SESSION['name'];
if(isset($_SESSION['name']))
{
	echo "hello" . $_SESSION['name'];
	?>
	<p>
	<a href="logout.php">LOGOUT</a>
	</p>
<?php
}

?>