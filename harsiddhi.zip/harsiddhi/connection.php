
<?php 
class connection
	{
		function connect()
		{
			$conn= mysqli_connect("localhost","root","","students");

			return $conn;
		}
	}
	

	?>