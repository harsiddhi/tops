
<?php 
class connection
	{
		function connect()
		{
			$co=new mysqli("localhost","root","","students");

			return $co;
		}
	}
	$conn=new connection;
	$con=$conn->connect();
	//print_r($conn);
	//print_r($con);
	//return $con;
	if($conn)
	{
		echo "connection done";
	}
	else
	{
		echo "connection not";
	}


	?>