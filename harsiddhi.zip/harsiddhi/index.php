
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
<h1>TOPS TECHNOLOGY</h1>
</center>
		<form method="post" name="student" action="controller/login.php">
		<center>

			<table border="1">
				<tr>
					<td>Name</td>
					<td><input type="text" name="email"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pass"></td>
				</tr>
					<tr>
					<td>
					<input type="hidden" name="action" value="login">
					</td>
					</tr>
				<tr>
				<td><input type="hidden" name="action" value="login"></td>

					<td><input type="submit" name="submit" value="submit"></td>
					<td><a href="view/insert.php">Registration</a>
					</td>

				</tr>

				
			</table>
			</center>
		</form>
		
</body>
</html>
